package com.example.angely.ejemplo1;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewAnimationUtils;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

public class ejem1 extends AppCompatActivity {

    private EditText inp_numero;
    private Button btn_action;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejem1);
        //viculando input
        inp_numero = (EditText) findViewById(R.id.inp_numero);
        inp_numero.setText("123456");


    }
    //creamos el metodo  boton presionado y creamos el objeto view
    public void boton_presionado(View view){
        //leyendo contenid de input
        String texto =inp_numero.getText().toString();
        Toast toast= Toast.makeText(
                getApplicationContext(),
                texto,
                Toast.LENGTH_LONG);
        toast.show();
    }
}
